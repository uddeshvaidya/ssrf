<?php
$command = $_GET['command'] ?? null;
$flight_id = $_GET['flight_id'] ?? null;

if ($command === 'abort' && $flight_id === 'UA987') {
    // Simulate aborting the flight
    echo "<h1>Air Traffic Control Dashboard</h1>";
    echo "<p>Flight ID: $flight_id</p>";
    echo "<p>Status: Aborted</p>";
    
    // Flag for successful abort
    echo "<script>alert('flag{mission_accomplished}');</script>";
    echo "<p><strong>Flag: flag{mission_accomplished}</strong></p>";
} else {
    echo "<h1>Air Traffic Control Dashboard</h1>";
    echo "<p>No action taken.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATC Dashboard - Udaan International Airport</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/atc_dashboard.js"></script>
</head>
<body>
    <div class="container">
        <h1>Air Traffic Control Dashboard</h1>
        <p>Flight ID: UA987</p>
        <p>Airline: Udaan Airways</p>
        <p>Flight Status: Almost Taking Off</p>

        <!-- CPDLC Control Buttons -->
        <button onclick="location.href='?command=cleared_takeoff&flight_id=UA987'">Cleared for Takeoff</button>
        <button onclick="location.href='?command=cleared_landing&flight_id=UA987'">Cleared for Landing</button>
        <button onclick="location.href='?command=abort&flight_id=UA987'">Abort Takeoff</button>
        <button onclick="location.href='?command=abort_landing&flight_id=UA987'">Abort Landing</button>
        
        <!-- Radar System Simulation -->
        <div id="radar">
            <div id="radar-circle"></div>
            <div id="plane"></div>
        </div>

        <!-- Weather Forecast (Wind Direction) -->
        <div id="weather">
            <h2>Weather Forecast</h2>
            <div id="wind-direction">
                <div id="wind-arrow"></div>
                <p id="wind-speed">Wind Speed: 15 km/h</p>
            </div>
        </div>
    </div>
</body>
</html>
