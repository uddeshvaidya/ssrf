window.onload = function() {
    // Radar System Animation
    const radarCircle = document.getElementById('radar-circle');
    const plane = document.getElementById('plane');
    let angle = 0;
    
    // Function to animate radar rotation
    function animateRadar() {
        angle += 0.5;  // Increase the angle for rotation
        if (angle >= 360) angle = 0;  // Reset the angle
        
        radarCircle.style.transform = `rotate(${angle}deg)`;
        
        // Move plane along the radar
        plane.style.transform = `rotate(${angle}deg) translate(100px)`;
    }
    
    setInterval(animateRadar, 50); // Update the radar every 50ms

    // Wind Direction Simulation
    const windArrow = document.getElementById('wind-arrow');
    const windSpeed = document.getElementById('wind-speed');
    
    // Set random wind direction
    let windDirection = Math.floor(Math.random() * 360);
    let speed = Math.floor(Math.random() * 20) + 5; // Random wind speed between 5 and 25 km/h
    
    windArrow.style.transform = `rotate(${windDirection}deg)`;
    windSpeed.innerHTML = `Wind Speed: ${speed} km/h`;
};
