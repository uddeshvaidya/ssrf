<?php
// Flight status data (can be expanded to simulate real flight info)
$flight_data = [
    'UA123' => 'On Time',
    'UA456' => 'Delayed',
    'UA789' => 'Cancelled',
    'UA987' => 'Almost Taking Off'  // Special flight status for exploit
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Udaan International Airport - Flight Status</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Flight Status</h1>
        <table class="flight-table">
            <thead>
                <tr>
                    <th>Flight Number</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($flight_data as $flight_number => $status) : ?>
                    <tr>
                        <td><?php echo $flight_number; ?></td>
                        <td><?php echo $status; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
