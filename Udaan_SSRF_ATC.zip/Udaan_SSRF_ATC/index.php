<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Udaan International Airport - Flight Status</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Udaan International Airport</h1>
        <p>Click the button below to check the status of your flight:</p>
        <form action="flight_status.php" method="get">
            <button type="submit">Check Flight Status</button>
        </form>
    </div>
</body>
</html>
